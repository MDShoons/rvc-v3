# Applio

1-click launcher for [Applio](https://github.com/IAHispano/Applio)
