module.exports = {
  run: [{
    method: "fs.rm",
    params: {
      path: "applio"
    }
  }]
}
